@extends('admin.layouts.app')
@section('title', 'Order #{{ $order->order_id }}')

@section('content')
<style>
@import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');

:root {
    --ink:#0f0e17; --muted:#6b6b8a; --light:#f4f3ff; --border:#e4e1f5;
    --p1:#5b21b6; --p2:#7c3aed; --p3:#ede9fe; --green:#059669; --red:#dc2626;
}
* { font-family:'Sora',sans-serif; box-sizing:border-box; }
.mono { font-family:'JetBrains Mono',monospace; }

/* ── SCREEN ONLY ── */
.inv-page { background:#f0eefa; min-height:100vh; padding:32px 16px; }
.inv-wrap  { max-width:980px; margin:0 auto; display:flex; flex-direction:column; gap:20px; }

.action-bar { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; }
.page-title  { font-size:22px; font-weight:700; color:var(--ink); display:flex; align-items:center; gap:10px; }
.page-title span { font-size:13px; font-weight:500; color:var(--muted); background:#fff; border:1px solid var(--border); padding:3px 12px; border-radius:20px; }
.btn-bar   { display:flex; gap:8px; flex-wrap:wrap; }
.btn-ghost { background:#fff; border:1.5px solid var(--border); color:var(--ink); border-radius:10px; padding:8px 16px; font-size:13px; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:6px; transition:all .15s; cursor:pointer; }
.btn-ghost:hover { border-color:var(--p2); color:var(--p2); background:var(--p3); }
.btn-print { background:linear-gradient(135deg,var(--p2),var(--p1)); color:#fff; border:none; border-radius:10px; padding:8px 20px; font-size:13px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:6px; box-shadow:0 4px 14px rgba(124,58,237,.35); transition:all .15s; }
.btn-print:hover { transform:translateY(-1px); }

/* screen card */
.inv-card { background:#fff; border:1px solid var(--border); border-radius:20px; overflow:hidden; box-shadow:0 4px 30px rgba(91,33,182,.08); }

/* screen header */
.inv-head { background:linear-gradient(120deg,#2d1b69 0%,#5b21b6 50%,#7c3aed 100%); padding:32px 36px; display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:20px; position:relative; overflow:hidden; }
.inv-head::before { content:''; position:absolute; right:-60px; top:-60px; width:220px; height:220px; border-radius:50%; background:rgba(255,255,255,.05); }
.company-block img { height:54px; margin-bottom:12px; display:block; }
.company-block h2  { color:#fff; font-size:20px; font-weight:700; margin:0 0 6px; }
.company-block p   { color:rgba(255,255,255,.7); font-size:12.5px; margin:0; line-height:1.7; }
.invoice-meta      { text-align:right; }
.inv-label { color:rgba(255,255,255,.55); font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:.8px; }
.inv-id    { color:#fff; font-size:26px; font-weight:700; font-family:'JetBrains Mono',monospace; margin:4px 0 14px; }
.inv-date-row { color:rgba(255,255,255,.75); font-size:12px; margin-top:4px; }

/* status strip */
.status-strip { display:flex; border-bottom:1px solid var(--border); background:#faf8ff; flex-wrap:wrap; }
.ss-item  { flex:1; min-width:120px; padding:14px 20px; border-right:1px solid var(--border); }
.ss-item:last-child { border-right:none; }
.ss-label { font-size:10.5px; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:.5px; margin-bottom:6px; }
.ss-val   { font-size:13.5px; font-weight:700; color:var(--ink); }
.status-select { border:1.5px solid var(--border); border-radius:8px; padding:5px 10px; font-size:12.5px; font-weight:600; color:var(--ink); background:#fff; cursor:pointer; outline:none; transition:border .15s; }
.status-select:focus { border-color:var(--p2); box-shadow:0 0 0 3px rgba(124,58,237,.1); }

/* body */
.inv-body { padding:28px 36px; }
.info-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:28px; }
@media(max-width:600px){ .info-grid{ grid-template-columns:1fr; } }
.info-box { background:var(--light); border:1px solid var(--border); border-radius:16px; padding:20px; }
.info-box-title { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.7px; color:var(--p2); margin-bottom:14px; display:flex; align-items:center; gap:6px; }
.info-row-item  { display:flex; gap:8px; margin-bottom:8px; font-size:13px; }
.info-row-item:last-child { margin-bottom:0; }
.ir-label { color:var(--muted); font-weight:600; min-width:80px; flex-shrink:0; font-size:12px; }
.ir-val   { color:var(--ink); font-weight:500; word-break:break-word; }

/* items table */
.items-table-wrap { border:1px solid var(--border); border-radius:16px; overflow:hidden; margin-bottom:28px; }
table.items { width:100%; border-collapse:collapse; }
table.items thead th { background:#f3f0fc; color:var(--p1); font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.6px; padding:12px 16px; text-align:left; }
table.items thead th:last-child,
table.items thead th:nth-child(3),
table.items thead th:nth-child(4) { text-align:right; }
table.items tbody tr { border-top:1px solid var(--border); }
table.items tbody tr:hover { background:#faf8ff; }
table.items tbody td { padding:14px 16px; font-size:13px; color:var(--ink); }
table.items tbody td:last-child,
table.items tbody td:nth-child(3),
table.items tbody td:nth-child(4) { text-align:right; }
.product-name { font-weight:600; }
.qty-badge { background:var(--p3); color:var(--p2); border-radius:6px; padding:2px 10px; font-size:12px; font-weight:700; }

/* summary */
.summary-wrap { display:flex; justify-content:flex-end; margin-bottom:24px; }
.summary-box  { width:100%; max-width:340px; border:1px solid var(--border); border-radius:16px; overflow:hidden; }
.sum-row      { display:flex; justify-content:space-between; align-items:center; padding:11px 18px; border-bottom:1px solid var(--border); font-size:13px; }
.sum-row:last-child { border-bottom:none; }
.sum-row .s-label { color:var(--muted); font-weight:600; }
.sum-row .s-val   { font-weight:700; font-family:'JetBrains Mono',monospace; color:var(--ink); }
.sum-row.total-row { background:linear-gradient(135deg,var(--p2),var(--p1)); }
.sum-row.total-row .s-label,
.sum-row.total-row .s-val { color:#fff; font-size:15px; }
.sum-row.due-row  .s-val { color:var(--red); }
.sum-row.paid-row .s-val { color:var(--green); }
.sum-row.coupon-row .s-val { color:#d97706; }

/* toast */
#invToast { position:fixed; bottom:24px; right:24px; z-index:99999; padding:13px 20px; border-radius:12px; font-size:13px; font-weight:600; color:#fff; display:flex; align-items:center; gap:10px; box-shadow:0 8px 28px rgba(0,0,0,.15); opacity:0; transform:translateY(12px); transition:opacity .25s,transform .25s; pointer-events:none; min-width:220px; }
#invToast.show { opacity:1; transform:translateY(0); }


/* ══════════════════════════════════════════
   PRINT — exact original layout
══════════════════════════════════════════ */
@page {
    size: A4 portrait;
    margin: 0 !important;
}

@media print {
    html, body { margin:0 !important; padding:0 !important; }

    /* body hidden, only overlay visible */
    body { visibility:hidden !important; background:#fff !important; }
    #printOverlay {
        visibility:visible !important;
        position:fixed !important;
        top:0 !important; left:0 !important;
        width:100% !important;
        padding:14mm 14mm !important;
        background:#fff !important;
        font-family:'Segoe UI',Arial,sans-serif !important;
        font-size:13px !important;
        color:#111 !important;
        box-shadow:none !important;
        z-index:999999 !important;
    }
    #printOverlay * { visibility:visible !important; }

    /* company header */
    #printOverlay .p-company-header { text-align:center; margin-bottom:14px; }
    #printOverlay .p-company-name   { font-size:20px; font-weight:700; margin-bottom:4px; }
    #printOverlay .p-company-info   { font-size:12px; color:#444; margin-bottom:2px; }

    /* divider */
    #printOverlay .p-divider { border:none; border-top:1.5px solid #555; margin:12px 0; }

    /* info row */
    #printOverlay .p-info-row { display:flex !important; width:100%; }
    #printOverlay .p-col      { flex:1; }
    #printOverlay .p-col-right{ text-align:right; }
    #printOverlay .p-section-title { font-size:14px; font-weight:700; margin-bottom:8px; }
    #printOverlay .p-lbl  { font-weight:700; }
    #printOverlay .p-line { font-size:12.5px; margin-bottom:5px; }

    /* tables */
    #printOverlay .p-table { width:100% !important; border-collapse:collapse !important; font-size:13px; margin-bottom:14px; }
    #printOverlay .p-table th { background:#efefef !important; print-color-adjust:exact; font-weight:700; padding:8px 10px; border:1px solid #bbb !important; text-align:left; }
    #printOverlay .p-table td { padding:7px 10px; border:1px solid #ccc !important; }
    #printOverlay .p-table tbody tr:nth-child(even) td { background:#fafafa !important; print-color-adjust:exact; }
    #printOverlay .p-center { text-align:center; }
    #printOverlay .p-right  { text-align:right; }

    /* summary */
    #printOverlay .p-summary-wrap  { display:flex !important; justify-content:flex-end !important; }
    #printOverlay .p-summary-table { width:42% !important; }
    #printOverlay .p-summary-table th { background:#f5f5f5 !important; print-color-adjust:exact; text-align:left; }
}
</style>

{{-- ═══════════════════════════
     SCREEN VIEW
═══════════════════════════ --}}
<div class="inv-page" id="printSection">
<div class="inv-wrap">

    {{-- ACTION BAR --}}
    <div class="action-bar">
        <div class="page-title">
            <i class="fa fa-file-invoice" style="color:var(--p2);"></i>
            Order Details
            <span>#{{ $order->order_id }}</span>
        </div>
        <div class="btn-bar">
            <a href="{{ route('admin.orders.edit', $order->id) }}" class="btn-ghost">
                <i class="fa fa-pen"></i> Edit
            </a>
            <a href="{{ route('admin.all-orders') }}" class="btn-ghost">
                <i class="fa fa-arrow-left"></i> Back
            </a>
            <button class="btn-print" id="printBtn">
                <i class="fa fa-print"></i> Print Invoice
            </button>
        </div>
    </div>

    {{-- SCREEN CARD --}}
    <div class="inv-card">

        {{-- gradient header --}}
        <div class="inv-head">
            <div class="company-block">
                <img src="{{ Storage::url($setting->header_logo) }}" alt="Logo">
                <h2>{{ $setting->company_name }}</h2>
                <p>
                    <i class="fa fa-phone me-1"></i>{{ $setting->phone_one }}<br>
                    <i class="fa fa-envelope me-1"></i>{{ $setting->email_one }}<br>
                    <i class="fa fa-map-marker-alt me-1"></i>{{ $setting->address }}
                </p>
            </div>
            <div class="invoice-meta">
                <div class="inv-label">Invoice</div>
                <div class="inv-id">#{{ str_pad($order->order_id,5,'0',STR_PAD_LEFT) }}</div>
                <div class="inv-date-row"><i class="fa fa-calendar-alt me-1"></i>{{ $order->created_at->format('d M Y') }}</div>
                @if($order->delivery_date)
                <div class="inv-date-row mt-1"><i class="fa fa-truck me-1"></i>Delivery: {{ \Carbon\Carbon::parse($order->delivery_date)->format('d M Y') }}</div>
                @endif
            </div>
        </div>

        {{-- status strip --}}
        <div class="status-strip">
            <div class="ss-item">
                <div class="ss-label">Payment Status</div>
                <select id="payment_status" class="status-select">
                    <option value="paid"   {{ $order->payment_status=='paid'   ?'selected':'' }}>✅ Paid</option>
                    <option value="unpaid" {{ $order->payment_status=='unpaid' ?'selected':'' }}>❌ Unpaid</option>
                </select>
            </div>
            <div class="ss-item">
                <div class="ss-label">Order Status</div>
                <select id="order_status" class="status-select">
                    <option value="pending"    {{ $order->status=='pending'    ?'selected':'' }}>🕐 Pending</option>
                    <option value="processing" {{ $order->status=='processing' ?'selected':'' }}>⚙️ Processing</option>
                    <option value="on the way" {{ $order->status=='on the way' ?'selected':'' }}>🚚 On The Way</option>
                    <option value="on hold"    {{ $order->status=='on hold'    ?'selected':'' }}>⏸️ On Hold</option>
                    <option value="courier"    {{ $order->status=='courier'    ?'selected':'' }}>📦 Courier</option>
                    <option value="completed"  {{ $order->status=='completed'  ?'selected':'' }}>✅ Completed</option>
                    <option value="cancelled"  {{ $order->status=='cancelled'  ?'selected':'' }}>❌ Cancelled</option>
                </select>
            </div>
            <div class="ss-item">
                <div class="ss-label">Payment Method</div>
                <div class="ss-val">{{ ucfirst($order->payment_method ?? 'N/A') }}</div>
            </div>
            <div class="ss-item">
                <div class="ss-label">Total Items</div>
                <div class="ss-val mono">{{ $order->orderItems->sum('quantity') }} pcs</div>
            </div>
        </div>

        {{-- body --}}
        <div class="inv-body">

            <div class="info-grid">
                <div class="info-box">
                    <div class="info-box-title"><i class="fa fa-user"></i> Customer Info</div>
                    <div class="info-row-item"><span class="ir-label">Name</span><span class="ir-val">{{ $order->user->name ?? 'Guest' }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Phone</span><span class="ir-val mono">{{ $order->user->phone ?? 'N/A' }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Email</span><span class="ir-val">{{ $order->user->email ?? 'N/A' }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Address</span><span class="ir-val">{{ $order->user->address ?? 'N/A' }}</span></div>
                    @if($order->delivery_area)
                    <div class="info-row-item"><span class="ir-label">Delivery</span><span class="ir-val">{{ $order->delivery_area }}</span></div>
                    @endif
                </div>
                <div class="info-box">
                    <div class="info-box-title"><i class="fa fa-shopping-bag"></i> Order Info</div>
                    <div class="info-row-item"><span class="ir-label">Invoice</span><span class="ir-val mono">#{{ $order->order_id }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Date</span><span class="ir-val">{{ $order->created_at->format('d M Y, h:i A') }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Total</span><span class="ir-val mono" style="color:var(--p1);font-weight:700;">{{ currency() }}{{ number_format($order->total,2) }}</span></div>
                    <div class="info-row-item"><span class="ir-label">Paid</span><span class="ir-val mono" style="color:var(--green);font-weight:700;">{{ currency() }}{{ number_format($order->paid??0,2) }}</span></div>
                    @if($order->note)
                    <div class="info-row-item"><span class="ir-label">Note</span><span class="ir-val" style="color:var(--muted);">{{ $order->note }}</span></div>
                    @endif
                </div>
            </div>

            <div class="items-table-wrap">
                <table class="items">
                    <thead>
                        <tr>
                            <th>#</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($order->orderItems as $item)
                        <tr>
                            <td style="color:var(--muted);font-size:12px;font-weight:600;">{{ $loop->iteration }}</td>
                            <td><div class="product-name">{{ $item->product->name ?? 'Product' }}</div></td>
                            <td><span class="qty-badge">{{ $item->quantity }}</span></td>
                            <td class="mono">{{ currency() }}{{ number_format($item->price,2) }}</td>
                            <td class="mono" style="font-weight:700;color:var(--p1);">{{ currency() }}{{ number_format($item->quantity*$item->price,2) }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="summary-wrap">
                <div class="summary-box">
                    <div class="sum-row"><span class="s-label">Subtotal</span><span class="s-val">{{ currency() }}{{ number_format($order->total,2) }}</span></div>
                    <div class="sum-row"><span class="s-label">Delivery Charge</span><span class="s-val">{{ currency() }}{{ number_format($order->delivery_charge??0,2) }}</span></div>
                    @if(($order->coupon??0)>0)
                    <div class="sum-row coupon-row"><span class="s-label">🎟️ Coupon</span><span class="s-val">-{{ currency() }}{{ number_format($order->coupon,2) }}</span></div>
                    @endif
                    <div class="sum-row total-row"><span class="s-label">Grand Total</span><span class="s-val">{{ currency() }}{{ number_format($order->total,2) }}</span></div>
                    <div class="sum-row paid-row"><span class="s-label">Paid</span><span class="s-val">{{ currency() }}{{ number_format($order->paid??0,2) }}</span></div>
                    @if(($order->total-($order->paid??0))>0)
                    <div class="sum-row due-row"><span class="s-label">Due</span><span class="s-val">{{ currency() }}{{ number_format($order->total-($order->paid??0),2) }}</span></div>
                    @endif
                </div>
            </div>

        </div>{{-- /inv-body --}}
    </div>{{-- /inv-card --}}


    {{-- ═══════════════════════════════════════
         PRINT INVOICE — original layout (hidden on screen)
    ═══════════════════════════════════════ --}}
    <div id="printInvoice" style="display:none;">

        {{-- Company Info (no logo) --}}
        <div class="p-company-header">
            <div class="p-company-name">{{ $setting->company_name }}</div>
            <div class="p-company-info">Phone: {{ $setting->phone_one }}</div>
            <div class="p-company-info">Email: {{ $setting->email_one }}</div>
            <div class="p-company-info">Address: {{ $setting->address }}</div>
        </div>

        <div class="p-divider"></div>

        {{-- Customer & Order --}}
        <div class="p-info-row">
            <div class="p-col">
                <div class="p-section-title">Customer Info</div>
                <div class="p-line"><span class="p-lbl">Name:</span> {{ $order->user->name ?? 'Guest' }}</div>
                <div class="p-line"><span class="p-lbl">Phone:</span> {{ $order->user->phone ?? 'N/A' }}</div>
                <div class="p-line"><span class="p-lbl">Address:</span> {{ $order->user->address ?? 'N/A' }}</div>
            </div>
            <div class="p-col p-col-right">
                <div class="p-section-title">Order Info</div>
                <div class="p-line"><span class="p-lbl">Invoice ID:</span> {{ $order->order_id }}</div>
                <div class="p-line"><span class="p-lbl">Date:</span> {{ $order->created_at->format('d M Y') }}</div>
                <div class="p-line"><span class="p-lbl">Total:</span> {{ currency() }}{{ number_format($order->total,2) }}</div>
            </div>
        </div>

        <div class="p-divider"></div>

        {{-- Items Table --}}
        <table class="p-table p-mb">
            <thead>
                <tr>
                    <th style="width:40px;">#</th>
                    <th>Product</th>
                    <th style="width:60px;">Qty</th>
                    <th style="width:100px;">Price</th>
                    <th style="width:110px;">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($order->orderItems as $item)
                <tr>
                    <td class="p-center">{{ $loop->iteration }}</td>
                    <td>{{ $item->product->name ?? 'Product Name' }}</td>
                    <td class="p-center">{{ $item->quantity }}</td>
                    <td class="p-right">{{ currency() }}{{ number_format($item->price,2) }}</td>
                    <td class="p-right">{{ currency() }}{{ number_format($item->quantity*$item->price,2) }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        {{-- Summary --}}
        <div class="p-summary-wrap">
            <table class="p-table p-summary-table">
                <tbody>
                    <tr><th>Total</th><td class="p-right">{{ currency() }}{{ number_format($order->total,2) }}</td></tr>
                    <tr><th>Delivery Charge</th><td class="p-right">{{ currency() }}{{ number_format($order->delivery_charge??0,2) }}</td></tr>
                    @if(($order->coupon??0)>0)
                    <tr><th>Coupon</th><td class="p-right">-{{ currency() }}{{ number_format($order->coupon,2) }}</td></tr>
                    @endif
                    <tr><th>Paid</th><td class="p-right">{{ currency() }}{{ number_format($order->paid??0,2) }}</td></tr>
                    <tr><th>Due</th><td class="p-right">{{ currency() }}{{ number_format($order->total-($order->paid??0),2) }}</td></tr>
                </tbody>
            </table>
        </div>

    </div>{{-- /printInvoice --}}

</div>{{-- /inv-wrap --}}
</div>{{-- /inv-page / printSection --}}

{{-- Toast --}}
<div id="invToast">
    <i id="invToastIcon" class="fa fa-check-circle"></i>
    <span id="invToastMsg"></span>
</div>

<script>
function showToast(msg, type='success') {
    const t = document.getElementById('invToast');
    document.getElementById('invToastMsg').textContent = msg;
    document.getElementById('invToastIcon').className  = type==='success' ? 'fa fa-check-circle' : 'fa fa-times-circle';
    t.style.background = type==='success' ? 'linear-gradient(135deg,#7c3aed,#5b21b6)' : '#dc2626';
    t.classList.add('show');
    clearTimeout(t._t);
    t._t = setTimeout(()=>t.classList.remove('show'), 3000);
}

function updateStatus(field, value) {
    fetch("{{ route('admin.orders.updateStatus', $order->id) }}", {
        method:'POST',
        headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}','Content-Type':'application/json'},
        body: JSON.stringify({ field, value })
    })
    .then(r=>r.json())
    .then(data => {
        if(data.success) showToast(field==='payment_status' ? 'Payment status updated!' : 'Order status updated!');
        else showToast('Failed to update!','error');
    })
    .catch(()=>showToast('Something went wrong!','error'));
}

document.getElementById('payment_status').addEventListener('change', function(){ updateStatus('payment_status', this.value); });
document.getElementById('order_status').addEventListener('change',   function(){ updateStatus('status', this.value); });

document.getElementById('printBtn').addEventListener('click', function() {
    const overlay = document.createElement('div');
    overlay.id = 'printOverlay';
    overlay.innerHTML = document.getElementById('printInvoice').innerHTML;
    document.body.appendChild(overlay);

    // visibility hidden — overlay নিজে visible থাকবে CSS এ
    document.body.style.visibility = 'hidden';

    setTimeout(function() {
        window.print();
        setTimeout(function() {
            document.body.style.visibility = '';
            document.body.removeChild(overlay);
        }, 500);
    }, 150);
});

</script>
@endsection